my_string="hello,world"
for char in my_string:
    print(char,end=" ")