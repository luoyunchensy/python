with open('fish.txt', 'w') as f:
    f.write('鲤鱼\n')
    f.write('草鱼\n')
    f.write('鲫鱼\n')
    f.write('鳙鱼\n')
    f.write('鲈鱼\n')

with open('fish.txt', 'r') as f:
    data = f.read()
    print(data)


import openpyxl

fishbook = openpyxl.Workbook()

fishsheet = fishbook.active

fishsheet.cell(1, 1, '鱼类名称')
fishsheet.cell(1, 2, '鱼类特性')

fish_dict = {'f1': ['鲤鱼', '杂食性'],
             'f2': ['草鱼', '食草性'],
             'f3': ['鲫鱼', '温水性'],
             'f4': ['鳙鱼', '温水性'],
             'f5': ['黑鱼', '肉食性']}

row = 2
for key, value in fish_dict.items():
    fishsheet.cell(row, 1, value[0])
    fishsheet.cell(row, 2, value[1])
    row += 1

fishbook.save('excel.xlsx')
