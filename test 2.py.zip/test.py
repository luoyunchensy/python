fish_list = ['鲤鱼', '草鱼', '鲫鱼', '鳙鱼', '鲈鱼']

fish_name = input("请输入鱼的名称：")
if fish_name in fish_list:
    index = fish_list.index(fish_name)
    print("find，序号为", index)
else:
    print("no find")

for i in range(len(fish_list)):
    print(i, fish_list[i])


fish_dict = {'f1': ['鲤鱼', '杂食性'], 'f2': ['草鱼', '食草性'], 'f3': ['鲫鱼', '温水性'], 'f4': ['鳙鱼', '温水性'], 'f5': ['黑鱼', '肉食性']}

fish_name = input("请输入鱼的名称：")
if fish_name in [v[0] for v in fish_dict.values()]:
    for key, value in fish_dict.items():
        if value[0] == fish_name:
            print("find，序号为", key)
else:
    print("no find")

for key, value in fish_dict.items():
    print(key, value[0], value[1])
