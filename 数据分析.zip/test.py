import pandas as pd
#import matplotlib as plt

data = [['f1','鲤鱼','杂食性',300],
        ['f2','草鱼','食草性',240],
        ['f3','鲫鱼','温水性',500],
        ['f4','鳙鱼','温水性',400],
        ['f5','黑鱼','肉食性',480]]

df = pd.DataFrame(data,columns=['鱼号','鱼名','习性','产量'])

ret = df.iloc[[1,3],[0,1,2,3]]

print(ret)
