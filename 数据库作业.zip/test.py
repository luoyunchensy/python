import sqlite3
conn = sqlite3.connect('fish.db')
c = conn.cursor()
#c.execute('''CREATE TABLE fish1
#             (fid TEXT PRIMARY KEY, fname TEXT, fhabit TEXT)''')

c.execute("INSERT INTO fish1 VALUES ('f1','鲤鱼','杂食性')")
c.execute("INSERT INTO fish1 VALUES ('f2','草鱼','食草性')")
c.execute("INSERT INTO fish1 VALUES ('f3','鲫鱼','温水性')")
c.execute("INSERT INTO fish1 VALUES ('f4','鳙鱼','温水性')")
c.execute("INSERT INTO fish1 VALUES ('f5','黑鱼','肉食性')")

conn.commit()
c.execute("SELECT * FROM fish1")
rows = c.fetchall()
for row in rows:
    print(row)

conn.close()