class Fish:
    def __init__(self, fid, fname):
        self.fid = fid
        self.fname = fname
    
    def live(self):
        print(f"{self.fname}：分布于我国，栖息于江河、湖泊中。")

class FreshwaterFish(Fish):
    def __init__(self, fid, fname, fhabit):
        super().__init__(fid, fname)
        self.fhabit = fhabit
    
    def live(self):
        super().live()
        print(f"属{self.fhabit}性鱼类。")

fish = Fish("001", "草鱼")
fish.live()  

freshwater_fish = FreshwaterFish("002", "水煮鱼", "食草")
freshwater_fish.live()  
