def find1(list, x):
    if x in list:
        print('find')
    else:
        print('no find')

fish_list = ['鲤鱼', '草鱼', '鲫鱼', '鳙鱼', '鲈鱼']
find1(fish_list, '鳊鱼')

def find2(dict, x):
    if x in dict.values():
        print('find')
    else:
        print('no find')


fish_dict = {'f1': ['鲤鱼', '杂食性'], 'f2': ['草鱼', '食草性'], 'f3': ['鲫鱼', '温水性'], 'f4': ['鳙鱼', '温水性'], 'f5': ['黑鱼', '肉食性']}
find2(fish_dict, '鲤鱼') 
